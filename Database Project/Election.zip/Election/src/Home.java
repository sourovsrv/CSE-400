
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class Home extends javax.swing.JFrame {
 private Connection con;
    private Statement st;
    private ResultSet rs;
    
    public void Data(){
        try{
            Class.forName("com.mysql.jdbc.Driver");       
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/election","root","");
            st= con.createStatement();   
            
        }catch(Exception ex){
        System.out.println("Surver not found !!!!!");
        }
    } 
    public boolean insert_data(String vid , String eid, String status){
     try{
      //Calendar calendar = Calendar.getInstance();
     // java.sql.Date startDate = new java.sql.Date(calendar.getTime().getTime());
       // the mysql insert statement
      String query = " insert into velectionreg(VID,Eid,status)"  + " values (?, ?, ?)";
      // create the mysql insert preparedstatement
            PreparedStatement preparedStmt = con.prepareStatement(query);
            preparedStmt.setString (1, vid);
            preparedStmt.setString (2, eid);
            preparedStmt.setString(3, status);
      // execute the preparedstatement
      preparedStmt.execute();
      return true;
      //con.close();
    }catch (Exception e){
              System.err.println("Got an exception at insert");
              System.err.println(e.getMessage());
              return false;
     }
  }
    public Home() {
        initComponents();
        Data();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        bpostinfo = new javax.swing.JButton();
        bcandidateinfo = new javax.swing.JButton();
        bvoterinfo = new javax.swing.JButton();
        bvelectionreg = new javax.swing.JButton();
        bcelectionreg = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("Homepage");

        bpostinfo.setText("Post Information");
        bpostinfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bpostinfoActionPerformed(evt);
            }
        });

        bcandidateinfo.setText("Cadidate Registration");
        bcandidateinfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcandidateinfoActionPerformed(evt);
            }
        });

        bvoterinfo.setText("Voter Registration");
        bvoterinfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bvoterinfoActionPerformed(evt);
            }
        });

        bvelectionreg.setText("Voter Election Regsitration");
        bvelectionreg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bvelectionregActionPerformed(evt);
            }
        });

        bcelectionreg.setText("Candidate Election Regsitration");
        bcelectionreg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcelectionregActionPerformed(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jButton6.setText("Vote");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(252, 252, 252)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(bpostinfo)))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(79, 79, 79)
                                    .addComponent(bcandidateinfo))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(69, 69, 69)
                                    .addComponent(bcelectionreg)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(85, 85, 85)
                                    .addComponent(bvoterinfo))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(69, 69, 69)
                                    .addComponent(bvelectionreg)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(225, 225, 225)
                        .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(136, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(bpostinfo)
                .addGap(56, 56, 56)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bcandidateinfo)
                    .addComponent(bvoterinfo))
                .addGap(52, 52, 52)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bcelectionreg)
                    .addComponent(bvelectionreg))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 56, Short.MAX_VALUE)
                .addComponent(jButton6)
                .addGap(48, 48, 48))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bpostinfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bpostinfoActionPerformed
        postinfo ps= new postinfo();
        ps.setVisible(true);
    }//GEN-LAST:event_bpostinfoActionPerformed

    private void bcandidateinfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcandidateinfoActionPerformed
        candidateinfo ci=new candidateinfo();
        ci.setVisible(true);
    }//GEN-LAST:event_bcandidateinfoActionPerformed

    private void bvoterinfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bvoterinfoActionPerformed
        Voterinfo vi=new Voterinfo();
        vi.setVisible(true);
    }//GEN-LAST:event_bvoterinfoActionPerformed

    private void bcelectionregActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcelectionregActionPerformed
        celectionreg celec= new celectionreg();
        celec.setVisible(true);
    }//GEN-LAST:event_bcelectionregActionPerformed

    private void bvelectionregActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bvelectionregActionPerformed
        velectionreg velec=new velectionreg();
        velec.setVisible(true);
    }//GEN-LAST:event_bvelectionregActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        votecast vc= new votecast();
        vc.setVisible(true);
    }//GEN-LAST:event_jButton6ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bcandidateinfo;
    private javax.swing.JButton bcelectionreg;
    private javax.swing.JButton bpostinfo;
    private javax.swing.JButton bvelectionreg;
    private javax.swing.JButton bvoterinfo;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
